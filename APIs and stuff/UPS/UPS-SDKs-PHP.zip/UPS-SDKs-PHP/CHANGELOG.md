# Changelog

## 1.0.0 - 2024-08-05
### Initial Release
- First version - OAuth Token SDK: Client Credentials & Auth Code Flows
